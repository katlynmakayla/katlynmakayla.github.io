const tripsEndpoint = 'http://localhost:3000/api/trips';
const options = {
method: 'GET',
headers: {
'Accept': 'application/json'
}
};
// var fs = require("node:fs");
// var trips = JSON.parse(  fs.readFileSync("./data/trips.json", "utf8"));

/*GET travel view*/
const travel = async function (req, res, next) {
  // console.log('TRAVEL CONTROLLER BEGIN');
  await fetch(tripsEndpoint, options)
    .then((res) => res.json())
    .then((json) => {
      let message = null;
      if (!Array.isArray(json) || json.length === 0) {
        message = "API lookup error";
        json = [];
      } else if (!json.length) {
          message = "No trips exist in our database";
        }
      // console.log(json);
      res.render('travel', { title: 'Travel - Travlr Getaways', trips: json, message}); 
    })
    .catch((err) => res.status(500).send(err.message));
  };

module.exports = {
  travel,
};  